List items = [
  {
    "header": "I-SUCIALIZE",
    "description":
        "This application is just the place for socializing as it provides its users maximum functionality in order to simplify chatting and sharing posts",
    "image": "lib/assets/images/1.png"
  },
  {
    "header": "Experience!",
    "description":
        "This is a Reddit like application that you can “SUcialize” easily through hashtags and posts. You can spend time here as long as you want, look at other posts, learn new opinions and experience different things with others",
    "image": "lib/assets/images/2.png"
  },
  {
    "header": "Share, Meet!",
    "description":
        "Share any information that you want via posts and chat, gather and talk about any topic you like, meet new people and get to know them better",
    "image": "lib/assets/images/3new.png"
  },
  {
    "header": "Discover!",
    "description":
        "Discover new ideas, ask questions, find topics you are interested in, enrich yourself. Be eager and open, may the force and this app be with you! :) ",
    "image": "lib/assets/images/4new.png"
  },
  {
    "header": "Enjoy!",
    "description":
        "Now that you know about this app, you are all good to go! Just enjoy your time while using this app!",
    "image": "lib/assets/images/5new.png"
  }
];
