package com.example.i_sucialize

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
